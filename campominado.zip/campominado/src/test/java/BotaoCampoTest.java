import br.com.cod3r.cm.modelo.Campo;
import br.com.cod3r.cm.modelo.CampoEvento;
import br.com.cod3r.cm.visao.BotaoCampo;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

import static org.junit.jupiter.api.Assertions.*;

public class BotaoCampoTest{

    @Test
    void testEventoOcorreu_Abrir() {
        Campo campo = new Campo(0, 0);
        BotaoCampo botao = new BotaoCampo(campo);

        // Simula o evento "ABRIR" no campo
        botao.eventoOcorreu(campo, CampoEvento.ABRIR);

        // Verifica se o estilo foi aplicado corretamente
        assertEquals(Color.GRAY, BorderFactory.createLineBorder(Color.GRAY)); // Cor de fundo após abrir

    }

}
