import br.com.cod3r.cm.modelo.*;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

class TabuleiroTest {

    private boolean notificouFimJogo;
    private boolean notificouGanhouJogo;
    private CampoObservador observador;
    private Campo campo;


    @Test
    void testCriarTabuleiro() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        assertNotNull(tabuleiro);
        assertEquals(5, tabuleiro.getLinhas());
        assertEquals(5, tabuleiro.getColunas());
    }

    @Test
    void testParaCadaCampo() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        int[] count = {0};
        tabuleiro.paraCadaCampo(c -> count[0]++);
        assertEquals(25, count[0]);
    }

    @Test
    void testAbrir() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.abrir(0, 0);
    }

    @Test
    void testAlternarMarcacao() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.alternarMarcacao(2, 3);
    }

    @Test
    void testObjetivoAlcancado() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        // Defina manualmente células para atender ao objetivo
        // Adicione asserções para verificar se o objetivo é alcançado
    }

    @Test
    void testReiniciar() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.reiniciar();

    }

//    @Test
//    void testEventoOcorreuExplosao() {
//        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 3);
//
//        // Suponhamos que você deseje testar o campo na linha 3, coluna 3
//        Campo campo = tabuleiro.getCampo(3, 3);
//        campo.minar(); // Simula uma mina no campo
//
//        tabuleiro.eventoOcorreu(campo, CampoEvento.EXPLODIR);
//
//        assertTrue(campo.isAberto()); // Verifica se o campo foi aberto
//        assertFalse(campo.isMarcado()); // Verifica se o campo não está marcado
//    }

}

